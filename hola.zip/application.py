from flask import Flask, render_template, redirect, url_for, request, session, flash, jsonify
from flask_mysqldb import MySQL
import feedparser
import requests
import logging
from logging.handlers import RotatingFileHandler


application = Flask(__name__)
application.config['SECRET_KEY'] = 'canyougetmeajob@4436318663'

application.logger.setLevel(logging.INFO)  # Adjust as needed
log_handler = RotatingFileHandler('application.log', maxBytes=100000, backupCount=3)
log_formatter = logging.Formatter('[%(asctime)s] %(levelname)s in %(module)s: %(message)s')
log_handler.setFormatter(log_formatter)
application.logger.addHandler(log_handler)

    # Set Flask app configuration for MySQL from the loaded db configuration
application.config['MYSQL_HOST'] = 'rajat-rds-endpoint.amazonaws.com'
application.config['MYSQL_USER'] = 'rajat_root'
application.config['MYSQL_PASSWORD'] = 'rajat'
application.config['MYSQL_DB'] = 'flaskapp'


mysql = MySQL(application)

def fetch_cybersecurity_news():
    """Fetches the latest cybersecurity news from The Hacker News."""
    feed_url = 'https://feeds.feedburner.com/TheHackersNews'
    news_feed = feedparser.parse(feed_url)
    news_items = [{'title': entry.title, 'description': entry.description,'link': entry.link} for entry in news_feed.entries[:5]]
    return news_items

@application.route('/')
def index():
    news_items = fetch_cybersecurity_news()
    return render_template('index.html', news_items=news_items)

@application.route('/about')
def about():
    if not session.get('registered'):
        flash('Please register to access this page.', 'warning')
        return redirect(url_for('register'))
    return render_template('about.html')

@application.route('/logout')
def logout():
    session.pop('registered', None)  # Remove 'registered' from session
    flash('You have been logged out.', 'info')
    # For simplicity, just redirecting back to the home page after logout
    return redirect(url_for('index'))


@application.route('/register', methods=['GET', 'POST'])
def register():

    news_items = fetch_cybersecurity_news()

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cur = mysql.connection.cursor()
        try:
            cur.execute("INSERT INTO users(name, email, password) VALUES(%s, %s, %s)", (username, email, password))
            mysql.connection.commit()
            application.logger.info(f"User registered: {username}")
            session['registered'] = True  # Set session variable upon successful registration
            flash('Registration successful!', 'success')
            return redirect(url_for('about'))
        except Exception as e:
            application.logger.error(f"Registration failed for {username}: {e}")
            mysql.connection.rollback()
            flash('Registration failed. Please try again later.', 'danger')
        finally:
            cur.close()
       
        # After registration, redirect to about page
        return redirect(url_for('about'))
    return render_template('register.html', news_items=news_items)



if __name__ == '__main__':
    application.run(debug=True)
